Hướng dẫn chạy chương trình phân tích cú pháp
========================
# 1. Dịch file
* Mở terminal tại nơi chứa file parser.c và thực hiện lệnh sau: ``gcc parser.c -o a.out``

# 2. Chạy chương trình
* Thực hiện lệnh: ``./a.out "đường dẫn file mã nguồn pl0"``