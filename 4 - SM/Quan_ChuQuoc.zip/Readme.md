Hướng dẫn chạy chương trình
========================
# 1. Dịch file
* Mở terminal tại nơi chứa các file *.c và thực hiện lệnh sau: ``gcc *.c``

# 2. Chạy chương trình
* Thực hiện lệnh: ``./a.out "đường dẫn file mã nguồn pl0"``