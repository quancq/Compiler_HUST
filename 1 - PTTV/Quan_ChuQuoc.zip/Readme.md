Hướng dẫn chạy chương trình
========================
# 1. Dịch file
* Mở terminal tại nơi chứa file scanner.c và thực hiện lệnh sau: ``gcc scanner.c -o a.out``

# 2. Chạy chương trình
* Thực hiện lệnh: ``./a.out "đường dẫn file mã nguồn pl0 cần dịch"``